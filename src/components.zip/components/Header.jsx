import React from "react";

function Header(props) {
  return (
    <div>
      <div className="header">
        <div className="header__inner">
          <div className="logo">
            <img className="logo" src="img/logo.png" />
          </div>
          <div className="search">
            <input type="search_space" placeholder="" aria-label="Search" />
            <i className="bi bi-search"></i>
          </div>
          <div className="link">
            <a href="/#">
              <span className="word">네이버를 시작페이지로</span>
            </a>  
            <a href="/#">
              <span className="word">쥬니버네이버</span>
            </a>
            <a href="/#">
              <span className="word">해피빈</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
