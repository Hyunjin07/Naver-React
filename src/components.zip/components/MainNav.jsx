import React from "react";

function MainNav(props) {
  return (
    <div>
      <div className="nav">
        <ul>
          <li>
            <a className="nav_green" href="/">
              메일
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              카페
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              블로그
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              지식iN
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              쇼핑
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              Pay
            </a>
          </li>
          <li>
            <a className="nav_green" href="/">
              TV
            </a>
          </li>
          <li>
            <a href="/">사전</a>
          </li>
          <li>
            <a href="/">뉴스</a>
          </li>
          <li>
            <a href="/">증권</a>
          </li>
          <li>
            <a href="/">부동산</a>
          </li>
          <li>
            <a href="/">지도</a>
          </li>
          <li>
            <a href="/">영화</a>
          </li>
          <li>
            <a href="/">뮤직</a>
          </li>
          <li>
            <a href="/">책</a>
          </li>
          <li>
            <a href="/">웹툰</a>
          </li>
          <li>
            <a href="/">더보기</a>
          </li>
        </ul>
      </div>
    </div>
  );
}

export default MainNav;
