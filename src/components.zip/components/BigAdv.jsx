import React from "react";

function BigAdv(props) {
  return (
    <div className="container">
      <div className="box1">
        <img className="adv" src="img/adv.png" />
      </div>
    </div>
  );
}

export default BigAdv;
