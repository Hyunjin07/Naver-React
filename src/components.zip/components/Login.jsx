import React from "react";

function Login(props) {
  return (
    <div className="container">
      <div className="box2" id="login_box">
        <br />
        <p>네이버를 더 안전하고 편리하게 이용하세요</p>
        <div className="login">
          {" "}
          <a href="/#">
            <span>NAVER</span>로그인
          </a>
        </div>
        <p id="p_tag">
          아이디 * 비밀번호 찾기 &nbsp;&emsp;&emsp;&emsp;&emsp;회원가입{" "}
        </p>
      </div>
    </div>
  );
}

export default Login;
